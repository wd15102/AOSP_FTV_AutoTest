import os
import sys

import configparser
import codecs
import threading

USER_MAIN_PATH = os.path.expanduser('~')

DEF_CONFIG_PATH = USER_MAIN_PATH + "/.Monitor/config/"
DEF_CONFIG_FILE_NAME = "monitor.config"
DEF_CONFIG_FILE = DEF_CONFIG_PATH + DEF_CONFIG_FILE_NAME

DEF_MAX_RETRY_TIMES = 3

Lock = threading.Lock()


class ConfigInfo(object):
    __instance = None

    def __init__(self):
        self.config()
        self.adbPath = self.get_adb_path()
        self.disWidth, self.disHeight = self.get_dis_size()

    def __new__(cls, *args, **kwargs):
        if not cls.__instance:
            try:
                Lock.acquire()
                # double check
                if not cls.__instance:
                    cls.__instance = super(ConfigInfo, cls).__new__(cls, *args, **kwargs)
            finally:
                Lock.release()
        return cls.__instance

    @staticmethod
    def getInstance():
        return ConfigInfo()

    def setAdbPath(self, path):
        self.adbPath = path
        self.set_adb_path(path)

    def setDisSize(self, dis_w, dis_h):
        self.disWidth = dis_w
        self.disHeight = dis_h
        self.set_dis_size(dis_w, dis_h)

    def getAdbPath(self):
        return self.adbPath

    def getDisSize(self):
        return self.disWidth, self.disHeight

    @staticmethod
    def config():
        if os.path.exists(DEF_CONFIG_PATH) is False:
            os.makedirs(DEF_CONFIG_PATH)
        # log_debug(LOG_TAG_CONFIG, DEF_CONFIG_FILE)
        if os.path.exists(DEF_CONFIG_FILE) is False:
            f = open(DEF_CONFIG_FILE, "w")
            f.close()

    @staticmethod
    def get_adb_path(path=DEF_CONFIG_FILE):
        cp = configparser.ConfigParser()
        adb_path = ""
        with codecs.open(path, 'r') as f:
            cp.read_file(f)
            if cp.has_option("DEFAULT", "ADB_PATH"):
                adb_path = cp.get("DEFAULT", "ADB_PATH")
        return adb_path

    @staticmethod
    def get_dis_size(path=DEF_CONFIG_FILE):
        dis_width = 360
        dis_height = 640
        cp = configparser.ConfigParser()
        with codecs.open(path, 'r') as f:
            cp.read_file(f)
            if cp.has_option("DEFAULT", "DISPLAY_WIDTH"):
                dis_width = cp.get("DEFAULT", "DISPLAY_WIDTH")
            if cp.has_option("DEFAULT", "DISPLAY_HEIGHT"):
                dis_height = cp.get("DEFAULT", "DISPLAY_HEIGHT")
        return dis_width, dis_height

    @staticmethod
    def set_adb_path(value, path=DEF_CONFIG_FILE):
        cp = configparser.ConfigParser()
        with codecs.open(path, 'r') as f:
            cp.read_file(f)
        cp.set('DEFAULT', 'ADB_PATH', str(value))
        cp.write(open(path, 'w'))
        cp.write(sys.stdout)

    @staticmethod
    def set_dis_size(width, height, path=DEF_CONFIG_FILE):
        cp = configparser.ConfigParser()
        with codecs.open(path, 'r') as f:
            cp.read_file(f)
        cp.set("DEFAULT", "DISPLAY_WIDTH", str(width))
        cp.set("DEFAULT", "DISPLAY_HEIGHT", str(height))
        cp.write(open(path, 'w'))
        cp.write(sys.stdout)
