# -*- coding: utf-8 -*-
import threading


def log_debug(*args):
    print(args)


class AppGlobal(object):
    _instance_lock = threading.Lock()
    cur_device = None

    def __new__(cls, *args, **kwargs):
        if not hasattr(AppGlobal, "_instance"):
            with AppGlobal._instance_lock:
                if not hasattr(AppGlobal, "_instance"):
                    AppGlobal._instance = object.__new__(cls)
        return AppGlobal._instance

    def set_device(self, device):
        self.cur_device = device

    def get_device(self):
        return self.cur_device
